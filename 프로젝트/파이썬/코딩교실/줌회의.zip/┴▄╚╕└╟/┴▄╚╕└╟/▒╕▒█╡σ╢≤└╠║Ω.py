import asyncio
import re
import os
import openpyxl
import shutil
import time
import pytz
from playwright.async_api import async_playwright, TimeoutError as PlaywrightTimeoutError
from playwright.sync_api import sync_playwright
from datetime import datetime, timedelta
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

fm = None
err = None
강의이름 = None
강의날짜 = None
폴더이름 = None
폴더정보 = {}
download = None
item = None
page = None
browser = None
new_handle = None
다운로드_작업들 = []

폴더경로 = os.path.dirname(os.path.abspath(__file__))  # 지금 코드 파일이 있는 위치를 저장
excel_file_path = os.path.join(폴더경로, '영상보내기.xlsx')  # 엑셀 파일 경로

def 엑셀():
    global 시트이름, 요일, 줌로그인, 줌링크, 줌아이디, 줌비번, 알람받을번호, 년도, 날짜, api키, 멘트1, 멘트2, 문자박스링크, 문자박스아이디, 문자박스비번, 지역리스트, 첫번째지역폴더, 두번째지역폴더, 세번째지역폴더, 첫번째시트링크, 두번째시트링크, 세번째시트링크, 첫번째드라이브링크, 두번째드라이브링크, 세번째드라이브링크, 타깃날짜
    wb = openpyxl.load_workbook(excel_file_path)
    ws = wb.active
    줌로그인 = ws.cell(row=1, column=15).value
    줌링크 = ws.cell(row=2, column=15).value
    줌아이디 = ws.cell(row=3, column=15).value
    줌비번 = ws.cell(row=4, column=15).value
    알람받을번호 = ws.cell(row=5, column=15).value
    년도 = ws.cell(row=1, column=17).value
    날짜 = ws.cell(row=2, column=17).value
    api키 = ws.cell(row=3, column=17).value
    멘트1 = ws.cell(row=4, column=17).value
    멘트2 = ws.cell(row=5, column=17).value
    문자박스링크 = ws.cell(row=6, column=17).value
    문자박스아이디 = ws.cell(row=7, column=17).value
    문자박스비번 = ws.cell(row=8, column=17).value
    지역이름 = ws.cell(row=9, column=17).value
    첫번째지역폴더 = ws.cell(row=10, column=17).value
    두번째지역폴더 = ws.cell(row=11, column=17).value
    세번째지역폴더 = ws.cell(row=12, column=17).value
    첫번째시트링크 = ws.cell(row=13, column=17).value
    두번째시트링크 = ws.cell(row=14, column=17).value
    세번째시트링크 = ws.cell(row=15, column=17).value
    첫번째드라이브링크 = ws.cell(row=16, column=17).value
    두번째드라이브링크 = ws.cell(row=17, column=17).value
    세번째드라이브링크 = ws.cell(row=18, column=17).value
    if '월' in 날짜 or '수' in 날짜:
        시트이름 = '출석부(월/수)'
        요일 = '월수'
    elif '화' in 날짜 or '목' in 날짜:
        시트이름 = '출석부(화/목)'
        요일 = '화목'
    else:
        kst = pytz.timezone('Asia/Seoul')
        now = datetime.now(kst)
        yesterday = now - timedelta(1)
        month = yesterday.month
        day = yesterday.day
        weekday_dict = {
            'Monday': '월',
            'Tuesday': '화',
            'Wednesday': '수',
            'Thursday': '목',
            'Friday': '금',
            'Saturday': '토',
            'Sunday': '일'
        }
        weekday_eng = yesterday.strftime('%A')
        weekday_kor = weekday_dict[weekday_eng]
        formatted_date = f"{month}/{day}"
        어제날짜 = f"{formatted_date}({weekday_kor})"
        날짜 = 어제날짜
        if weekday_kor in ['월', '수']:
            시트이름 = '출석부(월/수)'
            요일 = '월수'
        elif weekday_kor in ['화', '목']:
            시트이름 = '출석부(화/목)'
            요일 = '화목'
    if 날짜 == '자동':
        kst = pytz.timezone('Asia/Seoul')
        now = datetime.now(kst)
        yesterday = now - timedelta(1)
        타깃날짜 = yesterday.strftime(f"{년도}년 %m월 %d일")
    else:
        month_day = re.search(r"(\d+)/(\d+)", 날짜)
        if month_day:
            month = int(month_day.group(1))
            day = int(month_day.group(2))
            타깃날짜 = f"{년도}년 {month}월 {day}일"
    지역리스트 = []
    for line in 지역이름.strip().split('\n'):
        지역리스트.extend(line.split(','))

async def 로그인():
    global page  # 전역 변수로 사용
    await page.goto(줌로그인)  # Zoom 로그인 페이지로 이동
    await page.wait_for_load_state()
    await page.wait_for_selector('button#onetrust-accept-btn-handler', timeout=10000)  # 쿠키 허용 버튼 클릭
    await page.click('button#onetrust-accept-btn-handler')
    await asyncio.sleep(3)
    await page.fill('input#email', 줌아이디)  # 이메일 및 비밀번호 입력하고 로그인
    await page.fill('input#password', 줌비번)
    await asyncio.sleep(1)
    await page.press('#password', 'Enter')
    await page.wait_for_selector('span.font-bold:has-text("이앤오즈 주식회사")', timeout=30000)
    await page.goto(줌링크)  # 기록관리 페이지로 이동
    await asyncio.sleep(1)
    await page.wait_for_selector('//h1[contains(text(), "기록 관리") and contains(@style, "font-size: 24px;")]', timeout=30000)
    await asyncio.sleep(5)

async def 정보가져오기():
    global page, 강의이름, 강의날짜, 폴더정보, fm, err, 지역리스트
    try:
        if err == 1:
            return False
        fm = await page.query_selector('span.zm-table__empty-image:has-text("검색과 일치하는 결과를 찾을 수 없습니다")')
        if fm:
            return True  # 반복문을 종료하고 다음 작업으로 이동하기 위해 True 반환
        link_element = await page.query_selector('a.mgb-0.cursor-pointer.topic-actived')  # 첫 번째 회의 링크 찾기
        await link_element.click()
        await asyncio.sleep(1)
        error_count = await page.locator('div.error-wrap').count()
        if error_count > 0 and await page.locator('div.error-wrap').text_content() == "녹화가 너무 짧아 저장되지 않았습니다.":
            await page.goto(줌링크)
            await asyncio.sleep(1)
            first_button = await page.locator('button.grey.zm-button--icon.zm-button--plain.zm-button--icon-ghost.zm-button--icon.zm-button--mini.is-ghost.zm-button.zm-dropdown-selfdefine').first
            await first_button.click()
            await page.locator('div.textRed', has_text="삭제").click()
            await asyncio.sleep(3)
            await page.goto(줌링크)
            link_element = await page.query_selector('a.mgb-0.cursor-pointer.topic-actived')  # 첫 번째 회의 링크 찾기
            await link_element.click()
            await asyncio.sleep(1)
        await page.wait_for_selector('span.meeting-topic', timeout=30000)
        await asyncio.sleep(1)
        topic_element = await page.query_selector('span.meeting-topic')  # 회의 주제(타이틀) 가져오기
        if topic_element:
            강의이름 = await topic_element.inner_text()  # 강의 이름 가져오기
        date_element = await page.query_selector('span.mgr-md')  # 날짜 값 가져오기
        if date_element:
            date_text = await date_element.inner_text()  # 정규식을 사용하여 날짜 값을 추출
            pattern = r'(\d+년 \d+월 \d+일)'
            matches = re.search(pattern, date_text)
            강의날짜 = matches.group(1)
            폴더이름 = f"{강의이름}_{강의날짜}"  # 폴더 경로 설정 및 생성
            폴더경로_설정 = False
            for 지역명 in 지역리스트:
                if 지역명 in 강의이름:
                    폴더정보[강의이름] = os.path.join(폴더경로, '녹화영상', 지역명, 강의날짜, 폴더이름)
                    폴더경로_설정 = True
                    break
            if not 폴더경로_설정:
                폴더정보[강의이름] = os.path.join(폴더경로, '녹화영상', 강의날짜, 폴더이름)
            os.makedirs(폴더정보[강의이름], exist_ok=True)
    except Exception as e:
        print(f"{강의이름} 정보가져오기에서 오류 발생: {e}")  # 디버깅을 위한 오류 위치 출력
        err = 1
    return False

async def 삭제():
    global page, err  # 전역 변수로 사용
    try:
        if err:
            await page.goto(줌링크)  # 기록관리 페이지로 이동
            await asyncio.sleep(5)
            fm = None
            fm = await page.query_selector('span[role="alert"]:has-text("검색과 일치하는 결과를 찾을 수 없습니다")')
            if fm is not None:
                await asyncio.sleep(1)
                await page.wait_for_selector('//h1[contains(text(), "기록 관리") and contains(@style, "font-size: 24px;")]', timeout=30000)
                print(f"설치 재시작")              
                await asyncio.sleep(1)
            err = None
        else:
            delete_element = await page.query_selector('button:nth-child(4)')  # 삭제
            if delete_element:
                await delete_element.click()  # 버튼 누르기
                await asyncio.sleep(1)
                delete1_element = await page.query_selector('button.zm-button--primary.zm-button--small.zm-button > span')  # 휴지통으로 이동           
                await asyncio.sleep(1)
                if delete1_element: 
                    await page.get_by_role("button", name="휴지통으로 이동").click()  # 버튼 누르기
                    await asyncio.sleep(1)
                    await page.wait_for_load_state()            
            await asyncio.sleep(1)
            await page.reload() 
            await page.wait_for_selector('text=휴지통', timeout=30000)
            await asyncio.sleep(3)
    except Exception as e:
        print(f"{강의이름} 삭제에서 오류 발생: {e}")  # 디버깅을 위한 오류 위치 출력
        await page.goto(줌링크)  # 기록관리 페이지로 이동
        await asyncio.sleep(1)
        await page.wait_for_selector('//h1[contains(text(), "기록 관리") and contains(@style, "font-size: 24px;")]', timeout=30000)
        await asyncio.sleep(3)

async def 영상다운(강의이름, 이름):
    global item, browser, 강의날짜, new_handle, err  # 전역 변수로 사용
    try:
        await item.click()
        new_handle = None  # 새로 열린 창 핸들 얻기
        while not new_handle:
            for handle in browser.contexts[0].pages:
                if handle != page:
                    new_handle = handle
                    break
            await asyncio.sleep(1)
        await new_handle.wait_for_selector('a.download-btn', timeout=90000)  # 타임아웃 시간을 90초로 연장
        dl_element = await new_handle.query_selector('a.download-btn')  # 다운로드 버튼을 찾기
        if dl_element:
            async with new_handle.expect_download() as download_info:
                await dl_element.click()
                다운로드_작업들.append(asyncio.create_task(다운로드관리(download_info, 강의이름, 이름)))
            await new_handle.close()
            new_handle = None
            await page.wait_for_selector('span.meeting-topic', timeout=30000)
            await asyncio.sleep(1)
    except PlaywrightTimeoutError as e:
        print(f"{강의이름}의 {이름} 다운로드 대기열이 가득 찼습니다.")
        if new_handle:
            await new_handle.close()
            err = 1
    except Exception as e:
        print(f"{강의이름}의 {이름} 다운로드에서 예외 발생: {e}")
        if new_handle:
            await new_handle.close()
            err = 1

async def 다운로드관리(download_info, 강의이름, 이름):
    global err
    try:
        download = await download_info.value
        download_path = await download.path()
        target_path = os.path.join(폴더정보[강의이름], f"{강의이름}_{강의날짜}.mp4")
        shutil.move(download_path, target_path)  # 덮어쓰기 처리
    except Exception as e:
        print(f"{강의이름}의 {이름} 다운로드 이동 중 오류 발생: {e}")
        err = 1

async def 문자박스():
    await page.goto(문자박스링크)
    await asyncio.sleep(3)
    await page.fill('input[name="id"]', 문자박스아이디)
    await page.fill('input[name="pwd"]', 문자박스비번)
    await page.press('input[name="pwd"]', 'Enter')
    await asyncio.sleep(3)
    try:
        await page.click("a[onclick*='contentsLayerClose']")  # 닫기 버튼 클릭
    except:
        pass
    await asyncio.sleep(3)
    await page.fill('textarea#recvList', 알람받을번호)
    await page.fill('textarea#msg', '영상 다운로드 완료')
    print("모든 영상 다운로드 완료")
    await page.click('div.num_select')
    await asyncio.sleep(3)
    frame = page.frame(name='callbackFrame')
    await frame.wait_for_selector("a:has-text('01053006552')", timeout=30000)
    await frame.click("a:has-text('01053006552')")
    await page.click('a:has(img[src*="send_btn.gif"])')
    await asyncio.sleep(3)
    await page.keyboard.press('Enter')
    await asyncio.sleep(3)
    await page.keyboard.press('Enter')

async def 복사작업():
    global total_files_copied
    source_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), '녹화영상')
    경로 = [ # 각 지역에 해당하는 경로 리스트
        첫번째지역폴더,
        두번째지역폴더,
        세번째지역폴더
    ]
    def copy_all(src, dest): # 폴더와 파일 복사 함수
        file_count = 0
        if not os.path.exists(dest):
            os.makedirs(dest)
        for item in os.listdir(src):
            s = os.path.join(src, item)
            d = os.path.join(dest, item)
            try:
                if os.path.isdir(s):
                    if not os.path.exists(d):
                        os.makedirs(d)
                    file_count += copy_all(s, d)
                else:
                    shutil.copy2(s, d)
                    file_count += 1
            except Exception as e:
                print(f'Failed to copy {s} to {d}. Reason: {e}')
        return file_count
    total_files_copied = 0
    for i, region in enumerate(지역리스트): # 각 지역에 대해 작업
        region_folder = os.path.join(source_folder, region, 타깃날짜)
        if os.path.exists(region_folder) and os.path.isdir(region_folder):
            destination_path = os.path.join(경로[i], 요일)  # 목적지 폴더 경로 설정
            if not os.path.exists(destination_path):
                os.makedirs(destination_path)
            destination_date_folder = os.path.join(destination_path, 타깃날짜)  # 강의날짜 폴더를 복사
            if not os.path.exists(destination_date_folder):
                os.makedirs(destination_date_folder)
            files_copied = copy_all(region_folder, destination_date_folder)
            total_files_copied += files_copied
    
    sleep_duration = total_files_copied * 72
    completion_time = datetime.now() + timedelta(seconds=sleep_duration)
    print(f'총 {total_files_copied}개의 파일을 업로드 하고 있습니다. 예상 소요시간: {sleep_duration}초, 예상 완료 시간: {completion_time.strftime("%Y-%m-%d %H:%M:%S")}')
    time.sleep(sleep_duration)
     
def 폴더찾기(드라이브, folder_name, parent_folder_id=None):
    query = f"name = '{folder_name}' and mimeType = 'application/vnd.google-apps.folder'"
    if parent_folder_id:
        query += f" and '{parent_folder_id}' in parents"
    results = 드라이브.files().list(q=query, fields="files(id, name, webViewLink)").execute()
    items = results.get('files', [])
    if not items:
        raise ValueError(f"No folder named '{folder_name}' found.")
    return items[0]['id'], items[0].get('webViewLink')

def 하위폴더검색(드라이브, parent_folder_id):
    query = f"'{parent_folder_id}' in parents and mimeType = 'application/vnd.google-apps.folder'"
    results = 드라이브.files().list(q=query, fields="files(id, name)").execute()
    return results.get('files', [])

def 날짜가져오기(date_str):
    match = re.findall(r'\d+', date_str)
    if not match or len(match) < 2:
        raise ValueError("Invalid date format")
    return ''.join(match[-2:])

def 시트이름가져오기(url):
    match = re.search(r"/spreadsheets/d/([a-zA-Z0-9-_]+)", url)
    if not match:
        raise ValueError("Invalid Google Sheets URL")
    return match.group(1)

def 드라이브링크복사(드라이브링크):
    global 영상링크, 문자박스내용, 시트이름, 날짜, 요일, api키, a_value, 멘트1, 멘트2, e_value, j_value, l_value
    드라이브 = build('drive', 'v3', developerKey=api키)
    FOLDER_ID = re.search(r"/folders/([a-zA-Z0-9-_]+)", 드라이브링크).group(1)
    날짜가공 = 날짜가져오기(날짜)
    반이름 = f' {a_value}반'
    try:
        folder_id, _ = 폴더찾기(드라이브, 요일, parent_folder_id=FOLDER_ID)
        subfolders = 하위폴더검색(드라이브, folder_id)
        target_folder_id = None
        for subfolder in subfolders:
            try:
                if 날짜가져오기(subfolder['name']) == 날짜가공:
                    target_folder_id = subfolder['id']
                    break
            except ValueError:
                continue
        if target_folder_id:
            반_subfolders = 하위폴더검색(드라이브, target_folder_id)
            for subfolder in 반_subfolders:
                if 반이름 in subfolder['name']:
                    _, 영상링크 = 폴더찾기(드라이브, subfolder['name'], parent_folder_id=target_folder_id)
                    break
            if 영상링크:
                문자박스내용 = f"{멘트1}\n영상 링크 : {영상링크}\n{멘트2}"
            else:
                print("No matching 반 folder found.")
        else:
            print("No matching 날짜 folder found.")
    except ValueError as e:
        print(e)

def 날짜검색(시트데이터, search_value):
    for col_index, value in enumerate(시트데이터[1], start=1):
        if value == search_value:
            return col_index
    return None  

def 영상검색(시트데이터, column_index, search_value):
    rows = []
    for row_index, row in enumerate(시트데이터[1:], start=2):
        if len(row) >= column_index and row[column_index - 1] == search_value:
            rows.append(row_index)
    return rows

def 특정열값검색(시트데이터, rows, page, 드라이브링크, 시트링크):
    global a_value, j_value, l_value, e_value
    for row in rows:
        a_value = None
        current_row = row
        while current_row > 0:
            if len(시트데이터[current_row - 1]) > 0:
                a_value = 시트데이터[current_row - 1][0]
                if a_value:
                    break
            current_row -= 1
        e_value = 시트데이터[row - 1][4] if len(시트데이터[row - 1]) > 4 else None
        j_value = 시트데이터[row - 1][9] if len(시트데이터[row - 1]) > 9 else None
        l_value = 시트데이터[row - 1][11] if len(시트데이터[row - 1]) > 11 else None
        드라이브링크복사(드라이브링크)
        page.fill('textarea#recvList', j_value)
        if j_value == l_value:
            page.fill('textarea#recvList', j_value)
        else:
            page.fill('textarea#recvList', f'{j_value}\n{l_value}')

def 시트확인(page, 드라이브링크, 시트링크):
    global 날짜위치, 영상_행목록
    시트아이디 = 시트이름가져오기(시트링크)
    시트 = build('sheets', 'v4', developerKey=api키)
    range_name = f'{시트이름}'
    result = 시트.spreadsheets().values().get(spreadsheetId=시트아이디, range=range_name).execute()
    시트데이터 = result.get('values', [])
    if not 시트데이터:
        print("No data found.")
        return
    날짜위치 = 날짜검색(시트데이터, 날짜)
    if 날짜위치:
        영상_행목록 = 영상검색(시트데이터, 날짜위치, '영상')
        if 영상_행목록:
            특정열값검색(시트데이터, 영상_행목록, page, 드라이브링크, 시트링크)
        else:
            print(f'날짜 "{날짜}"에 "영상" 항목이 없습니다.')
    else:
        print(f'날짜 "{날짜}"가 시트에 둘째 줄에 없습니다.')

def 시트수정(시트링크):
    global 날짜위치, 영상_행목록, 시트이름, 폴더경로
    json_file_path = os.path.join(폴더경로, 'auto-send-link-105ad8c82efd.json')
    SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
    creds = Credentials.from_service_account_file(json_file_path, scopes=SCOPES)
    service = build('sheets', 'v4', credentials=creds)
    시트아이디 = 시트이름가져오기(시트링크)
    spreadsheet = service.spreadsheets().get(spreadsheetId=시트아이디).execute()
    sheet_id = None
    for sheet in spreadsheet['sheets']:
        if sheet['properties']['title'] == 시트이름:
            sheet_id = sheet['properties']['sheetId']
            break
    if sheet_id is None:
        raise ValueError(f"Sheet name '{시트이름}' not found in the spreadsheet")
    if not 영상_행목록:
        print("영상_행목록이 비어 있습니다. 업데이트를 건너뜁니다.")
        return
    requests = []
    for i in range(len(영상_행목록)):
        cell_range = f'{시트이름}!{chr(64 + 날짜위치)}{영상_행목록[i]}'  # 날짜위치는 열, 영상_행목록[i]는 행
        requests.append({
            'range': cell_range,
            'values': [['O']]
        })
    body = {
        'valueInputOption': 'RAW',
        'data': requests
    }
    service.spreadsheets().values().batchUpdate(
        spreadsheetId=시트아이디,
        body=body
    ).execute()
    requests = []
    for i in range(len(영상_행목록)):
        requests.append({
            "updateCells": {
                "range": {
                    "sheetId": sheet_id,
                    "startRowIndex": 영상_행목록[i] - 1,
                    "endRowIndex": 영상_행목록[i],
                    "startColumnIndex": 날짜위치 - 1,
                    "endColumnIndex": 날짜위치
                },
                "rows": [
                    {
                        "values": [
                            {
                                "userEnteredValue": {
                                    "stringValue": "O"
                                },
                                "note": "영상 발송 완료"
                            }
                        ]
                    }
                ],
                "fields": "note,userEnteredValue"
            }
        })
    if requests:
        body = {
            'requests': requests
        }
        service.spreadsheets().batchUpdate(
            spreadsheetId=시트아이디,
            body=body
        ).execute()
    else:
        print("업데이트할 요청이 없습니다. 건너뜁니다.")

def 문자박스로그인(page):
    page.goto(문자박스링크)
    time.sleep(3)
    page.fill('input[name="id"]', 문자박스아이디)
    page.fill('input[name="pwd"]', 문자박스비번)
    page.press('input[name="pwd"]', 'Enter')
    time.sleep(3)
    try:
        page.click("a[onclick*='contentsLayerClose']")  # 닫기 버튼 클릭
    except:
        pass

def 완료문자(page):
    page.fill('textarea#recvList', 알람받을번호)
    page.fill('textarea#msg', '영상 발송 완료')
    page.click('div.num_select')
    time.sleep(0.3)
    frame = page.frame(name='callbackFrame')
    frame.wait_for_selector("a:has-text('01053006552')", timeout=30000)
    frame.click("a:has-text('01053006552')")
    page.click('a:has(img[src*="send_btn.gif"])')
    time.sleep(0.3)
    page.keyboard.press('Enter')
    time.sleep(0.3)
    page.keyboard.press('Enter')    

async def 영상다운_업로드():
    global browser, page, item, err, 다운로드_작업들, total_files_copied  # 전역 변수로 사용
    async with async_playwright() as playwright:  # 크로미움 브라우저 열기
        browser = await playwright.chromium.launch(headless=False)
        page = await browser.new_page(accept_downloads=True)  # 새로운 창이 열리면 page에 저장
        엑셀()
        await 로그인()
        while True:
            완료 = await 정보가져오기()
            if 완료:
                break
            downloadlist = await page.query_selector_all('div.item_list_header.relative > a')  # 영상 다운로드 하기 위해 각 항목으로 접속
            for item in downloadlist:
                inner_text = await item.inner_text()
                if inner_text == "갤러리 보기가 포함된 공유 화면" or inner_text == "발표자 보기가 포함된 공유 화면":
                    await 영상다운(강의이름, '강의 영상')
            await 삭제()
            if 다운로드_작업들:
                await asyncio.gather(*다운로드_작업들)  # 모든 다운로드가 완료될 때까지 대기
        await 문자박스()
        await browser.close()
        await 복사작업()

def 링크보내기():
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(headless=False, args=['--disable-popup-blocking'])
        page = browser.new_page()
        time.sleep(3)
        문자박스로그인(page)
        for i, 지역명 in enumerate(지역리스트):
            시트링크 = [첫번째시트링크, 두번째시트링크, 세번째시트링크][i]
            드라이브링크 = [첫번째드라이브링크, 두번째드라이브링크, 세번째드라이브링크][i]
            시트확인(page, 드라이브링크, 시트링크)
            시트수정(시트링크)
        완료문자(page)
        print('모든 영상 링크 발송 완료')
        browser.close()

def main():
    asyncio.run(영상다운_업로드())
    링크보내기()

if __name__ == "__main__":
    main()
