# seosanAI > 2024-01-05 2:06pm
https://universe.roboflow.com/seosan-ai/seosanai

Provided by a Roboflow user
License: CC BY 4.0

