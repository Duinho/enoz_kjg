# Untitled - By: 17423 - 周三 4月 28 2021

import sensor, image, time, math, lcd, os, pyb
from pyb import UART, Pin, Timer


x0 = 48     # 吸取物块时，机械臂末端X坐标
y0 = -201 # 吸取物块时，机械臂末端Y坐标
z0 = 91    # 吸取物块时，机械臂末端Z坐标

z1 = 128    # 放置物块时，机械臂末端Z坐标

bx = 158    # 白色十字中心点X坐标
by = 138    # 白色十字中心点Y坐标

rc, dc, gc, bc, vc = 0


# 设置颜色阈值
thresholds = [(85, 100, -10, 10, 5, 40),    #r
              (25, 63, -30, 20, -40, 20),    #d
              (80, 100, -60, -30, -10, 20),   #g
              (70, 100, -30, -10, -30, 0),  #b
              (70, 100, 5, 20, -30, 0)]      #v

# 设置分拣区域
color_roi = (bx-15, by-15, 30, 30)
# 设置屏幕显示区域
lcd_roi = (bx-64, 40, 128, 160)

# 等待机械臂运动完成
def mirobot_wait_finish():
    inByte = ''
    print('wait')
    while inByte.find('>'):
        while uart.any() > 0:
            inByte = uart.readline().decode()
       #lcd.display(sensor.snapshot())
    #print(inByte)  # 打印机械臂返回数据，用于调试开发
    print('finish')

# 屏幕初始化
lcd.init()

# 设置串口端口
uart = UART(3, 115200)

# 设置按键引脚
Key = Pin('P6', Pin.IN, Pin.PULL_UP)
keyvalue = Key.value()          # 读取按钮状态

# 设置板载补光灯亮度
tim = Timer(4, freq=1000)           # 使用定时器4创建一个定时器对象-以1000Hz触发
Led = tim.channel(3, Timer.PWM, pin=Pin("P9"), pulse_width_percent=50)  # 配置Pin9的初始脉宽值百分比为50(打开板载补光灯）
pyb.delay(1000)
# 机械臂初始化
uart.write("$40 = 1\n")         # 设置机械臂打开回文
uart.write("$H\n")              # 机械臂复位
mirobot_wait_finish()           # 等待完成
pyb.delay(1000)
uart.write("M20 G90 G00 F2000\n")   # 设置机械臂笛卡尔运动模式
uart.write("M3S0\n")                # 关闭气泵

# 摄像头初始化
sensor.reset()                           # 初始化摄像头
sensor.set_pixformat(sensor.RGB565)      # 设置图像色彩格式为RGB565色彩图
sensor.set_framesize(sensor.QVGA)        # 将图像大小设置为QVGA (320x240)
sensor.skip_frames()                     # 等待设置生效
sensor.set_auto_gain(False)              # 如果使用颜色识别，必须关闭
sensor.set_auto_whitebal(False)          # 如果使用颜色识别，必须关闭
# 校准模式
if keyvalue==0:
    # 校准图像位置，等待直到按钮被按下
    while Key.value():
        img = sensor.snapshot()
        img.draw_cross(bx, by, color = (255, 255, 255), size = 10, thickness = 1)       # 画十字
        img.draw_rectangle(bx-65, by-13, 130, 26, color = (255, 255, 255), thickness = 1, fill = False)       # 画边长为100的方框
        lcd.display(img,roi = lcd_roi)
    uart.write('X'+str(x0) + 'Y'+str(y0) + 'Z'+str(z0+20) + '\n')       # 机械臂末端移动至物块正上方
    pyb.delay(1000)
    while Key.value():
        img = sensor.snapshot()
        img.draw_cross(bx, by, color = (255, 255, 255), size = 10, thickness = 1)       # 画十字
        img.draw_rectangle(bx-65, by-13, 130, 26, color = (255, 255, 255), thickness = 1, fill = False)       # 画边长为100的方框
        lcd.display(img,roi = lcd_roi)
    uart.write('M21G90G1X0Y0Z0A0B0C0\n')       # 机械臂回归零位

# 分拣物块
while(True):
    img = sensor.snapshot()                 # 获取图像
    img.draw_cross(bx, by, color = (255, 255, 255), size = 10, thickness = 1)
    img.draw_rectangle(bx-15, by-15, 30, 30, color = (255, 255, 255), thickness = 1, fill = False)
    lcd.display(img,roi = lcd_roi)
    # 在color_roi范围内查找色块
    for blob in img.find_blobs(thresholds, roi = color_roi, x_stride=20, y_stride=20,area_threshold=400):
        color = ''
        print(str(blob.code()))             # 打印阈值代号
        if blob.code() == 1:
            color = 'R'
            print('red')
            img.draw_string(blob.x(), blob.y() + 10, 'R')
            rc
        elif blob.code() == 2:
            color = 'Y'
            print('yellow')
            img.draw_string(blob.x(), blob.y() + 10, 'Y')
        elif blob.code() == 4:
            color = 'G'
            print('green')
            img.draw_string(blob.x(), blob.y() + 10, 'G')
        elif blob.code() == 8:
            color = 'B'
            print('blue')
            img.draw_string(blob.x(), blob.y() + 10, 'B')
        elif blob.code() == 16:
            color = 'V'
            print('violet')
            img.draw_string(blob.x(), blob.y() + 10, 'V')

        img.draw_cross(blob.cx(), blob.cy()) # 绘制十字
        img.draw_rectangle(blob.rect())      # 绘制方框
        lcd.display(img,roi = lcd_roi)                     # lcd显示

        break
